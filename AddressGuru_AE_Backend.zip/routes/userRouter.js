import express from "express";
const router = express.Router();

router.get("/user", async (req, res, next) => {
  return res.send({ Test: "User Router" });
});

export default router;
