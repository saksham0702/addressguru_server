import { fileURLToPath } from "url";
import { dirname, join } from "path";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

import createError from "http-errors";
import express from "express";
import cookieParser from "cookie-parser";
import logs from "morgan";
import cors from "cors";
import logger from "./services/logger.js";

// import indexRouter from "./routes/index.js";
// import usersRouter from "./routes/users.js";

import usersRouter from "./routes/userRouter.js";
import connectDB from "./config/connectDB.js";
import { API_PREFIX } from "./services/constant.js";

var app = express();

// view engine setup
app.set("views", join(__dirname, "views"));
app.set("view engine", "jade");
app.use(cors());
app.use(logs("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(join(__dirname, "public")));

app.get("/", async (req, res) => {
  const html = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>AddressGuru AE Backend</title>
      <style>
        body {
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
          background: #f0f2f5;
          color: #333;
          display: flex;
          align-items: center;
          justify-content: center;
          height: 100vh;
          margin: 0;
        }
        .container {
          text-align: center;
          background: white;
          padding: 2rem 3rem;
          box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
          border-radius: 10px;
        }
        h1 {
          color: #FF6E02;
        }
        p {
          font-size: 1.2rem;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <h1>🚀 AddressGuru AE Backend</h1>
        <p>Server is up and running smoothly!</p>
      </div>
    </body>
    </html>
  `;
  return res.send(html);
});

app.use(`/${API_PREFIX}/`, usersRouter);

// app.use("/", indexRouter);
// app.use("/users", usersRouter);

// Connect to Database
connectDB();

// catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404));
});

// error handler
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get("env") === "development" ? err : {};
  // Log error with Winston
  logger.error(
    `${err.status || 500} - ${err.message} - ${req.originalUrl} - ${
      req.method
    } - ${req.ip}`
  );

  // render the error page
  res.status(err.status || 500);
  res.render("error");
});

export default app;
