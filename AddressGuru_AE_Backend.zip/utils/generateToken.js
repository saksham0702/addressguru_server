const JWT = require("jsonwebtoken");
const { SECRET_KEY } = require("../services/constant");

const createJwtToken = (user) => {
  const jwtPayload = {
    user: {
      id: user._id,
      role: user.role,
      refId: user.refId,
    },
  };

  return JWT.sign(jwtPayload, SECRET_KEY, { expiresIn: "24h" });
};

module.exports = { createJwtToken };
