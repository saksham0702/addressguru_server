import * as dotenv from "dotenv";
dotenv.config();

export const PORT = process.env.PORT;
export const API_PREFIX = process.env.API_PREFIX;
export const ADMIN_PREFIX = process.env.ADMIN_API;
export const USER_PREFIX = process.env.USER_API;
export const JWT_KEY = process.env.JWT_KEY;
export const SECRET_KEY = process.env.SECRET_KEY;
export const MONGODB_URL = process.env.MONGODB_URL;
export const BASE_URL = process.env.API_URL;
export const API_IMAGE_PREFIX = process.env.API_IMAGE_PREFIX;
export const NODE_ENV = process.env.NODE_ENV;
